#include "PhysicsList.hh"
#include "G4SystemOfUnits.hh"

PhysicsList::PhysicsList() : G4VModularPhysicsList() {

  //SetDefaultCutValue(1*nanometer);
  //SetVerboseLevel(1);
}

PhysicsList::~PhysicsList(){}
