#include "PrimaryGeneratorAction.hh"

#include "G4RunManager.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"

#include "Randomize.hh"
#include <math.h>

PrimaryGeneratorAction::PrimaryGeneratorAction()
 : G4VUserPrimaryGeneratorAction(),
   fParticleGun(0),
   fIceBox(0) {

  G4int nofParticles = 1;
  fParticleGun = new G4ParticleGun(nofParticles);
}

PrimaryGeneratorAction::~PrimaryGeneratorAction() { delete fParticleGun; }

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent) {

  // Find geometry-defined length to orient gun, spit error and center if not found
  if (!fIceBox) {
    G4LogicalVolume* IceBoxLV
      = G4LogicalVolumeStore::GetInstance()->GetVolume("IceBox");
    if ( IceBoxLV ) fIceBox = dynamic_cast<G4Box*>(IceBoxLV->GetSolid());
  }
  // Place gun at origin
  fParticleGun->SetParticlePosition(G4ThreeVector());
  if ( fIceBox ) { 
    G4double IceBoxHalfLength = fIceBox->GetXHalfLength();
    // Replace gun at 2 * side length from origin
    fParticleGun->SetParticlePosition(G4ThreeVector(0, 0, 4*IceBoxHalfLength));
  }
  else  {
    G4ExceptionDescription msg;
    msg << "IceBox volume of box shape not found.\n";
    msg << "Perhaps you have changed geometry.\n";
    msg << "The gun will be place at the center.";
    G4Exception("B1PrimaryGeneratorAction::GeneratePrimaries()",
     "MyCode0002",JustWarning,msg);
  }

  // Aim Down
  fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0, 0, -1));

  // Fire
  fParticleGun->GeneratePrimaryVertex(anEvent);
}
