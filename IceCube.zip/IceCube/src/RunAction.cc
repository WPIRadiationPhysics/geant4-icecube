#include "RunAction.hh"
#include "PrimaryGeneratorAction.hh"
#include "DetectorConstruction.hh"

#include "G4Run.hh"
#include "G4RunManager.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4LogicalVolume.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4SolidStore.hh"
#include "G4GeometryManager.hh"
#include "G4EmCalculator.hh"

#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <sys/types.h>

RunAction::RunAction() : G4UserRunAction() {}

RunAction::~RunAction() { /* delete G4AnalysisManager::Instance(); */ }

void RunAction::BeginOfRunAction(const G4Run* /*run*/) {}

void RunAction::EndOfRunAction(const G4Run* /*run*/) {
	
  // Output; supress individual worker thread re-run
  //if ( isMaster ) {}
}
