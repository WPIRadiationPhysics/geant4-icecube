#include "DetectorConstruction.hh"

#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4PVReplica.hh"
#include "G4GlobalMagFieldMessenger.hh"
#include "G4AutoDelete.hh"
#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include "G4RunManager.hh"

G4ThreadLocal 
G4GlobalMagFieldMessenger* DetectorConstruction::fMagFieldMessenger = 0; 

DetectorConstruction::DetectorConstruction()
 : G4VUserDetectorConstruction(),
   fDetector(0),
   fCheckOverlaps(true) {

     // Acquire material data
     DefineMaterials();
}

DetectorConstruction::~DetectorConstruction() {}

G4VPhysicalVolume* DetectorConstruction::Construct() {

  // Define geometric volumes
  return DefineVolumes();
}

void DetectorConstruction::DefineMaterials() {
	
  // Materials defined using NIST Manager
  G4NistManager* nistManager = G4NistManager::Instance();
  nistManager->FindOrBuildMaterial("G4_WATER");
  
  // Custom Definition of ice
  G4double ice_density     = 0.9761*g/cm3;  // from Wikipedia
  G4double ice_pressure    = 101325*pascal; // 1 atm
  G4double ice_temperature = 273.15*kelvin;    // 0 deg C
  G4double ice_molarmass   = 18.0153*g/mole; // from WolframAlpha
  new G4Material("Ice", 10., ice_molarmass, ice_density,
                   kStateGas, ice_temperature, ice_pressure);
  
  // Geant4 conventional definition of a vacuum
  G4double vacuum_density     = universe_mean_density;  //from PhysicalConstants.h
  G4double vacuum_pressure    = 1.e-19*pascal;
  G4double vacuum_temperature = 0.1*kelvin;
  G4double vacuum_molarmass   = 1.01*g/mole; 
  new G4Material("Vacuum", 1., vacuum_molarmass, vacuum_density,
                   kStateGas, vacuum_temperature, vacuum_pressure);

  // Print materials
  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//// Geometry parameters
G4VPhysicalVolume* DetectorConstruction::DefineVolumes() {

  // Declarations
  G4double IceCubeLength = 1*km;                       // side length of bulk ice

  G4double IceCubeHalfLength = 0.5*IceCubeLength;     // half side length of bulk ice
  G4double worldBoxHalfLength = 2*IceCubeHalfLength; // half side length of world
           
  // Get materials
  G4Material* defaultMaterial = G4Material::GetMaterial("Vacuum");
  G4Material* iceMaterial = G4Material::GetMaterial("Ice");

  // Throw exception to ensure material usability
  if ( ! defaultMaterial ) {
    G4ExceptionDescription msg;
    msg << "Cannot retrieve materials already defined."; 
    G4Exception("DetectorConstruction::DefineVolumes()",
      "MyCode0001", FatalException, msg);
  }

  // World box
  // Box solid definition
  G4VSolid* worldS 
    = new G4Box(
            "worldBox",      // its name
            worldBoxHalfLength,  // parameters
            worldBoxHalfLength,
            worldBoxHalfLength
            );

  // World volume
  G4LogicalVolume* worldLV
    = new G4LogicalVolume(
            worldS,          // its solid
            defaultMaterial, // its material
            "world"          // its name
            );

  // World physical volume of solid placed in LV
  G4VPhysicalVolume* worldPV
    = new G4PVPlacement(
            0,                // no rotation
            G4ThreeVector(),  // no translation
            worldLV,          // its logical volume                         
            "worldLV",          // its name
            0,                // its mother  volume
            false,            // no boolean operation
            0,                // copy number
            fCheckOverlaps    // checking overlaps
            );
  // World visualization attributes
  G4VisAttributes* defaultVisAtt = new G4VisAttributes(G4Colour(1.0, 1.0, 1.0));
  defaultVisAtt->SetVisibility(true);
  worldLV->SetVisAttributes(defaultVisAtt);

  // IceCube box
  // Box solid definition
  G4VSolid* IceCubeS 
    = new G4Box(
            "IceCubeBox",   // its name
            IceCubeHalfLength,  // parameters
            IceCubeHalfLength,
            IceCubeHalfLength
            );

  // IceCube volume
  G4LogicalVolume* IceCubeLV
    = new G4LogicalVolume(
            worldS,          // its solid
            iceMaterial,     // its material
            "IceBox"         // its name
            );

  // IceCube Physical volume of solid placed in LV
  G4VPhysicalVolume* IceCubePV
    = new G4PVPlacement(
            0,                // no rotation
            G4ThreeVector(),  // no translation (from center of mother volume)
            IceCubeLV,        // its logical volume                         
            "IceCubeLV",        // its name
            worldLV,          // its mother  volume
            false,            // no boolean operation
            0,                // copy number
            fCheckOverlaps    // checking overlaps
            );


  // IceCube Visualization attributes
  G4VisAttributes* iceVisAtt = new G4VisAttributes(G4Colour(0, 0, 1.0));
  iceVisAtt->SetVisibility(true);
  IceCubeLV->SetVisAttributes(iceVisAtt);

  // Always return the physical World
  return worldPV;
}
